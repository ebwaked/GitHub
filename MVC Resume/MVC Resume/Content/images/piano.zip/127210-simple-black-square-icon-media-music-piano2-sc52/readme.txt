Thanks for downloading!

For licensing and FAQs please see our online readme: 
http://mysitemyway.com/etc-readme/